#!/bin/sh

VERSION=`grep VERSION glstarview.h | sed -e 's/#define VERSION \"\(.*\)\"/\1/'`

scp ../"glstarview-$VERSION".tar.gz leste.astro.northwestern.edu:public_html/code/glstarview/
