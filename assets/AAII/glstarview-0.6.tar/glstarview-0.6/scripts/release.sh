#!/bin/sh

make mrproper
cvs2cl

VERSION=`grep VERSION glstarview.h | sed -e 's/#define VERSION \"\(.*\)\"/\1/'`

DIR=`pwd | sed -e 's/^.*\/\(.*\)$/\1/'`
cd ..
mv "$DIR" "glstarview-$VERSION"
tar -cvzf "glstarview-$VERSION".tar.gz --exclude CVS "glstarview-$VERSION"
mv "glstarview-$VERSION" "$DIR"
cd "$DIR"
